CREATE USER 'bkav'@'%' IDENTIFIED WITH mysql_native_password BY 'entictorkSIDenHAesYCHeRUsIatioNIeCTREsGrayFEtrista';

-- ALTER USER 'bkav'@'%' IDENTIFIED WITH mysql_native_password BY 'entictorkSIDenHAesYCHeRUsIatioNIeCTREsGrayFEtrista';

GRANT ALL PRIVILEGES ON *.* TO 'bkav'@'%' WITH GRANT OPTION;

FLUSH PRIVILEGES;
